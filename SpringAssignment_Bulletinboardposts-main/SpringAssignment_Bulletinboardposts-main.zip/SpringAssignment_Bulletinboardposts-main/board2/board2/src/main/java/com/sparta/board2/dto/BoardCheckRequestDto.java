package com.sparta.board2.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

// 비밀번호 확인하기
@Getter
@NoArgsConstructor
public class BoardCheckRequestDto {
    private String password;

//    public BoardCheckRequestDto(String password) {
//        this.password = password;
//        System.out.println(this.password);
    }


